package com.example.thomasbartlettproject3_eventapp.login;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.thomasbartlettproject3_eventapp.R;
import com.example.thomasbartlettproject3_eventapp.eventsmain.EventsListActivity;
import com.example.thomasbartlettproject3_eventapp.sql.UsersSQLite;

public class LoginActivity extends AppCompatActivity {

    Activity activity;
    Button LoginButton, RegisterButton, ForgotPassButton;
    EditText Email, Password;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    PopupWindow popwindow;
    SQLiteDatabase db;
    UsersSQLite handler;
    String TempPassword = "NOT_FOUND";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterButton = findViewById(R.id.registerButton);
        ForgotPassButton = findViewById(R.id.forgotPasswordButton);
        Email = findViewById(R.id.editTextEmail);
        Password = findViewById(R.id.editTextPassword);
        handler = new UsersSQLite(this);

        // Adding click listener to sign in forgotPasswordButton
        LoginButton.setOnClickListener(view -> {
            // Call Login function
            LoginFunction();
        });

        // Adding click listener to register forgotPasswordButton.
        RegisterButton.setOnClickListener(view -> {
            // Opening new RegisterActivity using intent on forgotPasswordButton click.
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Adding click listener to register forgotPasswordButton.
        ForgotPassButton.setOnClickListener(view -> {
            EmailHolder = Email.getText().toString().trim();

            if (!EmailHolder.isEmpty()) {
                forgotPassPopup();

            } else {
                Toast.makeText(LoginActivity.this, "User E-mail is empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Login function
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {

            // Opening SQLite database write permission
            db = handler.getWritableDatabase();

            // Adding search email query to cursor
            Cursor cursor = db.query(UsersSQLite.TABLE_NAME, null, " " + UsersSQLite.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Storing Password and Name associated with entered email
                    TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLite.COLUMN_4_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLite.COLUMN_1_NAME));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLite.COLUMN_2_PHONE_NUMBER));

                    // Closing cursor.
                    cursor.close();
                }
            }
            handler.close();

            // Calling method to check final result
            CheckFinalResult();
        } else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking editText fields are not empty.
    public String CheckEditTextNotEmpty() {

        // Getting value from fields and storing into string variable
        String message = "";
        EmailHolder = Email.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();

        if (EmailHolder.isEmpty()) {
            Email.requestFocus();
            EmptyHolder = true;
            message = "User E-mail is empty";
        } else if (PasswordHolder.isEmpty()) {
            Password.requestFocus();
            EmptyHolder = true;
            message = "User Password is empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Checking entered password from SQLite database email associated password
    public void CheckFinalResult() {
        if (TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();

            // Sending Name to EventsListActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);

            // Going to EventsListActivity after login success message
            Intent intent = new Intent(LoginActivity.this, EventsListActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
            this.finish();

            // Empty editText  after login successful and close database
            EmptyEditTextAfterDataInsert();
        } else {

            // Display error message if credentials are not correct
            Toast.makeText(LoginActivity.this, "Incorrect Email or Password\nor User Not Registered", Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND";
    }

    // Empty edittext after login successful
    public void EmptyEditTextAfterDataInsert() {
        Email.getText().clear();
        Password.getText().clear();
    }

    // Popup for forgot password
    public void forgotPassPopup() {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_forgotpass_popup, activity.findViewById(R.id.activity_forgotpass_popup), false);

        //Create window for popup
        popwindow = new PopupWindow(layout, 800, 800, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        EditText name = layout.findViewById(R.id.editTextUserName);
        EditText phone = layout.findViewById(R.id.editTextForgotPhone);
        TextView password = layout.findViewById(R.id.textViewPassDisplay);

        // Opening SQLite database write permission
        db = handler.getWritableDatabase();

        // Adding search email query to cursor
        Cursor cursor = db.query(UsersSQLite.TABLE_NAME, null, " " + UsersSQLite.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();

                // Store Password and Name associated with email
                PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLite.COLUMN_2_PHONE_NUMBER));
                NameHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLite.COLUMN_1_NAME));
                TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLite.COLUMN_4_PASSWORD));

                // Close cursor
                cursor.close();
            }
        }
        handler.close();

        // Retrieve and cancel buttons
        Button retrieve = layout.findViewById(R.id.forgotRetrieveButton);
        Button cancel = layout.findViewById(R.id.forgotCancelButton);

        retrieve.setOnClickListener(view -> {
            String verifyName = name.getText().toString();
            String verifyPhone = phone.getText().toString();

            // Password retrieval requires exact name AND phone number, else invalid
            if (verifyPhone.equals(PhoneNumberHolder) && verifyName.equals(NameHolder)) {
                password.setText(TempPassword);

                new android.os.Handler().postDelayed(() -> popwindow.dismiss(), 3000);
            } else {
                Toast.makeText(activity, "Phone Number or Name is invalid", Toast.LENGTH_LONG).show();
            }
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(activity, "Forgot password canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }
}