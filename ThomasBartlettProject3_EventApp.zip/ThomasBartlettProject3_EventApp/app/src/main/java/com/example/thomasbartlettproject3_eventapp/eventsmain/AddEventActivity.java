package com.example.thomasbartlettproject3_eventapp.eventsmain;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.thomasbartlettproject3_eventapp.R;
import com.example.thomasbartlettproject3_eventapp.sql.EventsSQLite;
import com.example.thomasbartlettproject3_eventapp.tables.Event;

import java.util.concurrent.atomic.AtomicReference;

public class AddEventActivity extends AppCompatActivity {

    String EmailHolder, DateHolder, TimeHolder, DescriptionHolder;
    EditText DateValue, TimeValue, DescriptionValue;
    Button CancelButton, AddEventButton;
    Boolean EmptyHolder;
    EventsSQLite db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addevent);

        // Initiate buttons, textViews, and editText variables
        DateValue = findViewById(R.id.editTextEditDate);
        TimeValue = findViewById(R.id.editTextEditTime);
        DescriptionValue = findViewById(R.id.editTextEditDescription);
        CancelButton = findViewById(R.id.addEventCancelButton);
        AddEventButton = findViewById(R.id.addEventAddButton);
        db = new EventsSQLite(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving email from EventsListActivity
        EmailHolder = intent.get().getStringExtra(EventsListActivity.UserEmail);

        // Adding click listener to CancelButton
        CancelButton.setOnClickListener(view -> {

            // Going back to EventsListActivity after cancel
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Adding click listener to addEventButton and pass data to EventsListActivity
        AddEventButton.setOnClickListener(view -> InsertEventIntoDatabase());
    }

    // Insert event into database and send data to EventsListActivity
    public void InsertEventIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            String date = DateHolder;
            String time = TimeHolder;
            String description = DescriptionHolder;

            Event event = new Event(date, time, description);
            db.createEvent(event);

            // Display toast message after insert in table
            Toast.makeText(this, "Event has been added successfully", Toast.LENGTH_LONG).show();

            // Close AddEventActivity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {

            // Display toast message if item description is empty and focus the field
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking event description is not empty
    public String CheckEditTextNotEmpty() {

        // Getting value from fields and storing into string variable
        String message = "";
        DateHolder = DateValue.getText().toString().trim();
        TimeHolder = TimeValue.getText().toString().trim();
        DescriptionHolder = DescriptionValue.getText().toString().trim();

        // Checking if fields are empty
        if (DateHolder.isEmpty()) {
            DateValue.requestFocus();
            EmptyHolder = true;
            message = "Event \"Date\" is empty";
        } else if (TimeHolder.isEmpty()) {
            TimeValue.requestFocus();
            EmptyHolder = true;
            message = "Event \"Time\" is empty";
        } else if (DescriptionHolder.isEmpty()) {
            DescriptionValue.requestFocus();
            EmptyHolder = true;
            message = "Event \"Description\" is empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

}
