package com.example.thomasbartlettproject3_eventapp.login;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.thomasbartlettproject3_eventapp.R;
import com.example.thomasbartlettproject3_eventapp.sql.UsersSQLite;
import com.example.thomasbartlettproject3_eventapp.tables.User;

public class RegisterActivity extends AppCompatActivity {

    Button RegisterButton, CancelButton;
    EditText NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    UsersSQLite handler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        NameHolder = findViewById(R.id.editTextUserName);
        PhoneNumberHolder = findViewById(R.id.editTextPhone);
        EmailHolder = findViewById(R.id.editTextEmail);
        PasswordHolder = findViewById(R.id.editTextPassword);
        RegisterButton = findViewById(R.id.registerSignupButton);
        CancelButton = findViewById(R.id.registerCancelButton);
        handler = new UsersSQLite(this);

        // Adding click listener to register forgotPasswordButton
        RegisterButton.setOnClickListener(view -> {
            String message = CheckEditTextNotEmpty();

            if (!EmptyHolder) {
                // Check if email already exists in database
                CheckEmailAlreadyExists();
                // Empty editText fields after done inserting in database
                EmptyEditTextAfterDataInsert();
            } else {
                // Display toast message if any field is empty and focus the field
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Adding click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to LoginActivity after cancel Register
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            this.finish();
        });
    }

    // Register new user into database
    public void InsertUserIntoDatabase() {
        String name = NameHolder.getText().toString().trim();
        String phone = PhoneNumberHolder.getText().toString().trim();
        String email = EmailHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        User user = new User(name, phone, email, pass);
        handler.createUser(user);

        // Printing toast message after done inserting.
        Toast.makeText(RegisterActivity.this, "User successfully registered!\nFeel free to log in now.", Toast.LENGTH_LONG).show();

        // Going back to LoginActivity after register success message
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        this.finish();
    }

    // Checking item description is not empty
    public String CheckEditTextNotEmpty() {

        // Getting value from fields and storing into string variable
        String message = "";
        String name = NameHolder.getText().toString().trim();
        String phone = PhoneNumberHolder.getText().toString().trim();
        String email = EmailHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        // Check to make sure fields are populated
        if (name.isEmpty()) {
            NameHolder.requestFocus();
            EmptyHolder = true;
            message = "Name is empty";
        } else if (phone.isEmpty()) {
            PhoneNumberHolder.requestFocus();
            EmptyHolder = true;
            message = "Phone number is empty";
        } else if (email.isEmpty()) {
            EmailHolder.requestFocus();
            EmptyHolder = true;
            message = "E-mail address is empty";
        } else if (pass.isEmpty()) {
            PasswordHolder.requestFocus();
            EmptyHolder = true;
            message = "Password is empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Check if user email already exists in database
    public void CheckEmailAlreadyExists() {
        String email = EmailHolder.getText().toString().trim();
        db = handler.getWritableDatabase();

        // Adding search email query to cursor
        Cursor cursor = db.query(UsersSQLite.TABLE_NAME, null, " " + UsersSQLite.COLUMN_3_EMAIL + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If email exists then set result variable value as Email Found
                F_Result = "Email found";
                // Closing cursor.
                cursor.close();
            }
        }
        handler.close();

        // Calling method to check final result and insert data into SQLite database
        CheckFinalCredentials();
    }

    // Check login credentials are correct
    public void CheckFinalCredentials() {

        // Checking whether email is already in database
        if (F_Result.equalsIgnoreCase("Email found")) {

            // If email is exists then toast msg will display
            Toast.makeText(RegisterActivity.this, "Email already exists.\nTry logging in\nor use \"Forgot Password\"", Toast.LENGTH_LONG).show();
        } else {

            // If email already doesn't exists then user registration details will entered to SQLite database
            InsertUserIntoDatabase();
        }
        F_Result = "Not_Found";
    }

    // Empty edittext after done inserting in database
    public void EmptyEditTextAfterDataInsert() {
        NameHolder.getText().clear();
        PhoneNumberHolder.getText().clear();
        EmailHolder.getText().clear();
        PasswordHolder.getText().clear();
    }
}
