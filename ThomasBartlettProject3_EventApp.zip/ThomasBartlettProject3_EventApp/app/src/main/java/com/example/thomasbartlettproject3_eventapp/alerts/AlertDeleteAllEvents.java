package com.example.thomasbartlettproject3_eventapp.alerts;

import android.app.AlertDialog;

import com.example.thomasbartlettproject3_eventapp.R;
import com.example.thomasbartlettproject3_eventapp.eventsmain.EventsListActivity;

public class AlertDeleteAllEvents {

    public static AlertDialog doubleButton(final EventsListActivity context) {

        // Builder class for dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_delete_title)
                .setIcon(R.drawable.button_delete_all)
                .setCancelable(false)
                .setMessage(R.string.alert_delete_msg)
                .setPositiveButton(R.string.alert_delete_dialog_yes_button, (dialog, arg1) -> {
                    EventsListActivity.YesDeleteEvents();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_delete_dialog_no_button, (dialog, arg1) -> {
                    EventsListActivity.NoDeleteEvents();
                    dialog.cancel();
                });

        // AlertDialog object return
        return builder.create();
    }
}
